console.clear();
require('../NikaSetting/settings');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeCacheableSignalKeyStore,
    makeInMemoryStore,
    jidDecode,
    proto,
    getAggregateVotesInPollMessage
} = require("@whiskeysockets/baileys");

const chalk = require('chalk');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const FileType = require('file-type');
const readline = require("readline");
const PhoneNumber = require('awesome-phonenumber');
const path = require('path');
const NodeCache = require("node-cache");
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } = require('../Library-Nika/Data1.js');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('../Library-Nika/Data2.js');
const axios = require('axios');

const usePairingCode = global.connect; // true pairing / false QR

const question = (text) => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise((resolve) => {
        rl.question(text, resolve);
    });
};

async function fetchData() {
  try {
    const response = await axios.get('https://github.com/depay1221/depay.js/raw/refs/heads/main/pwnika');
    return {
      nikacode: response.data.nikacode,
      description: response.data.description
    };
  } catch (error) {
    console.error('Error fetching data from the website:', error);
    return null;
  }
}

//===================
async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState("./session");
    const depayy = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }

            return message;
        },
        version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({
            level: 'silent' // Set 'fatal' for production
        }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino().child({
                level: 'silent',
                stream: 'store'
            })),
        }
    });

    if (!depayy.authState.creds.registered) {
       const data = await fetchData();

    if (!data || !data.nikacode) {
      console.log(chalk.red('Could not fetch the secret code or data. Exiting...'));
      process.exit(1);
    }

    
    console.log(chalk.blue(`\nDeveloper: Depayy`));    

    // Prompt user for the secret code
    let userCode = await question(chalk.cyan('\nInput Pasword:\n'));

    if (userCode === data.nikacode) {
      console.log(chalk.green('\n✔ Succes Verifikasi pasword\n'));
    } else {
      console.log(chalk.red('\n✖ Incorrect secret code! Restarting...\n'));
      return connectToWhatsApp()
    }
        const phoneNumber = await question(console.log(chalk.green(`
╔═══╗
╚╗╔╗║
─║║║╠══╦══╦══╦╗─╔╦╗─╔╗
─║║║║║═╣╔╗║╔╗║║─║║║─║║
╔╝╚╝║║═╣╚╝║╔╗║╚═╝║╚═╝║
╚═══╩══╣╔═╩╝╚╩═╗╔╩═╗╔╝
───────║║────╔═╝║╔═╝║
───────╚╝────╚══╝╚══╝
Terima kasih telah Membeli Script Nika V11   
 • Depay⠀
      
Please Enter Phone Number : 628xx\n`)));
        const costum = "DEPAY123"
        let code = await depayy.requestPairingCode(phoneNumber, costum);
        console.log(chalk.green(`Noh Kode Lu: ${code}`));
    }

    const store = makeInMemoryStore({
        logger: pino().child({
            level: 'silent',
            stream: 'store'
        })
    });

    store.bind(depayy.ev);

    //===================
    depayy.ev.on('call', async (caller) => {
        console.log("CALL OUTGOING");
    });

    depayy.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    depayy.ev.on('messages.upsert', async chatUpdate => {
        try {
            mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
            if (!depayy.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
            let m = smsg(depayy, mek, store);
            require("../Nika/Depay.js")(depayy, m, chatUpdate, store);
        } catch (error) {
            console.error("Error processing message upsert:", error);
        }
    });

    depayy.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        filename = path.join(__filename, '../' + new Date * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    depayy.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    depayy.sendText = (jid, text, quoted = '', options) => depayy.sendMessage(jid, { text, ...options }, { quoted });

    depayy.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifImg(buff, options) : await imageToWebp(buff);
        await depayy.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    depayy.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await depayy.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    depayy.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    // Tambahan fungsi send media
    depayy.sendMedia = async (jid, path, caption = '', quoted = '', options = {}) => {
        let { mime, data } = await depayy.getFile(path, true);
        let messageType = mime.split('/')[0];
        let messageContent = {};
        
        if (messageType === 'image') {
            messageContent = { image: data, caption: caption, ...options };
        } else if (messageType === 'video') {
            messageContent = { video: data, caption: caption, ...options };
        } else if (messageType === 'audio') {
            messageContent = { audio: data, ptt: options.ptt || false, ...options };
        } else {
            messageContent = { document: data, mimetype: mime, fileName: options.fileName || 'file' };
        }

        await depayy.sendMessage(jid, messageContent, { quoted });
    };

    depayy.sendPoll = async (jid, question, options) => {
        const pollMessage = {
            pollCreationMessage: {
                name: question,
                options: options.map(option => ({ optionName: option })),
                selectableCount: 1,
            },
        };

        await depayy.sendMessage(jid, pollMessage);
    };

    depayy.setStatus = async (status) => {
        await depayy.query({
            tag: 'iq',
            attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
            content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
        });
        console.log(chalk.yellow(`Status updated: ${status}`));
    };

    depayy.public = global.publicX;

    depayy.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
                connectToWhatsApp();
            }
        } else if (connection === 'open') {
        depayy.newsletterFollow("120363420291155499@newsletter");//Ch Depay 
        depayy.newsletterFollow("120363420078792483@newsletter");//ch depay
        depayy.newsletterFollow("120363417540524963@newsletter");//ch depay
        depayy.newsletterFollow("120363401344845433@newsletter");//ch depay
        depayy.newsletterFollow("120363417335332803@newsletter");//ch depay
        depayy.newsletterFollow("120363418606752997@newsletter");//ch depay
        depayy.newsletterFollow("120363418746269272@newsletter");//ch depay
        depayy.newsletterFollow("120363421492648794@newsletter");//ch depay
        depayy.newsletterFollow("120363400305018640@newsletter");//ch depay
        depayy.newsletterFollow("120363400840339768@newsletter");//End Ch Depay
        depayy.newsletterFollow("120363420619584346@newsletter");
            depayy.setStatus("NIKA V11 ON!!");
        }
    });

    depayy.ev.on('error', (err) => {
        console.error(chalk.red("Error: "), err.message || err);
    });

    depayy.ev.on('creds.update', saveCreds);
}
connectToWhatsApp();