/*
Command Create By Xemzz
( t.me/XemzzXiterz )

Salin dan tempel ini di package.json👇🏻
"js-confuser": "^1.7.3",
"telegraf": "^4.12.3"
*/
bot.command('enchtml', async (ctx) => {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document || 
        !ctx.message.reply_to_message.document.file_name.endsWith('.html')) {
      return ctx.reply('💀 Silakan balas file .html untuk dienkripsi.');
    }

    const fileId = ctx.message.reply_to_message.document.file_id;
    const fileName = ctx.message.reply_to_message.document.file_name;

    await ctx.reply("⚡️ Memproses enkripsi HTML...");

    const fileLink = await ctx.telegram.getFileLink(fileId);
    const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const htmlBuffer = Buffer.from(response.data);
    const htmlContent = htmlBuffer.toString();

    function encryptHTML(html) {
      let encrypted = '';
      for (let i = 0; i < html.length; i++) {
        encrypted += String.fromCharCode(html.charCodeAt(i) + 1);
      }
      
      const base64Encoded = Buffer.from(encrypted).toString('base64');
      
      return `<!DOCTYPE html>
<html>
<head>
<title>Xemzz nih boss</title>
<script>
function decrypt() {
    var encrypted = "${base64Encoded}";
    var decoded = atob(encrypted);
    var decrypted = "";
    for (var i = 0; i < decoded.length; i++) {
        decrypted += String.fromCharCode(decoded.charCodeAt(i) - 1);
    }
    document.write(decrypted);
}
</script>
</head>
<body onload="decrypt()">
<!-- Telegram @XemzzXiterz -->
</body>
</html>`;
    }

    const encryptedHTML = encryptHTML(htmlContent);
    const encryptedFilePath = `./encrypted_${fileName}`;
    fs.writeFileSync(encryptedFilePath, encryptedHTML);

    await ctx.replyWithDocument({
      source: fs.createReadStream(encryptedFilePath),
      filename: `ByXemzz_HTML_${fileName}`
    }, {
      caption: `╭━━━「 ✅ SUKSES 」━━━⬣\n│ File HTML berhasil dienkripsi!\n│ @XemzzXiterz\n╰━━━━━━━━━━━━━━━━⬣`
    });

    fs.unlinkSync(encryptedFilePath);

  } catch (error) {
    console.error("Gagal mengenkripsi HTML:", error);
    ctx.reply('❌ Terjadi kesalahan saat mengenkripsi file HTML.');
  }
});