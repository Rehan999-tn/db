/*
Command Create By Xemzz
( t.me/XemzzXiterz )

Salin dan tempel ini di package.json👇🏻
"node-telegram-bot-api": "^0.64.0"
*/
bot.onText(/\/enchtml/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  try {
    if (!msg.reply_to_message || !msg.reply_to_message.document || 
        !msg.reply_to_message.document.file_name.endsWith('.html')) {
      return bot.sendMessage(chatId, '💀 Silakan balas file .html untuk dienkripsi.');
    }

    const fileId = msg.reply_to_message.document.file_id;
    const fileName = msg.reply_to_message.document.file_name;

    await bot.sendMessage(chatId, "⚡️ Memproses enkripsi HTML...");

    const fileLink = await bot.getFileLink(fileId);
    const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const htmlBuffer = Buffer.from(response.data);
    const htmlContent = htmlBuffer.toString();

    function encryptHTML(html) {
      let encrypted = '';
      for (let i = 0; i < html.length; i++) {
        encrypted += String.fromCharCode(html.charCodeAt(i) + 1);
      }
      
      const base64Encoded = Buffer.from(encrypted).toString('base64');
      
      return `<!DOCTYPE html>
<html>
<head>
<title>Xemzz nih boss</title>
<script>
function decrypt() {
    var encrypted = "${base64Encoded}";
    var decoded = atob(encrypted);
    var decrypted = "";
    for (var i = 0; i < decoded.length; i++) {
        decrypted += String.fromCharCode(decoded.charCodeAt(i) - 1);
    }
    document.write(decrypted);
}
</script>
</head>
<body onload="decrypt()">
<!-- Telegram @XemzzXiterz -->
</body>
</html>`;
    }

    const encryptedHTML = encryptHTML(htmlContent);
    const encryptedFilePath = `./encrypted_${fileName}`;
    fs.writeFileSync(encryptedFilePath, encryptedHTML);

    await bot.sendDocument(chatId, encryptedFilePath, {}, {
      filename: `ByXemzz_HTML_${fileName}`,
      caption: `╭━━━「 ✅ SUKSES 」━━━⬣\n│ File HTML berhasil dienkripsi!\n│ @XemzzXiterz\n╰━━━━━━━━━━━━━━━━⬣`
    });

    fs.unlinkSync(encryptedFilePath);

  } catch (error) {
    console.error("Gagal mengenkripsi HTML:", error);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengenkripsi file HTML.');
  }
});