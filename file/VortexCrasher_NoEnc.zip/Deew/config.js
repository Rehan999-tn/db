module.exports = {
  BOT_TOKEN: "BAHAN BYPAS LO",
  OWNER_ID: ["7106738671"],
};

// Developer : @DEWNOTDEVNEW
// Name Script : VORTEXGUARD
// Channel : https://t.me/DEWNEWERA
// Note : This is Vortex Brow...!!